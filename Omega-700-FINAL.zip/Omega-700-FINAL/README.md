# Omega-700-FINAL
Next.js frontend for Google-Shahan (Ω-700).
